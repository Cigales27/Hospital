﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Estaciona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void txtcontrol_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("SOLO NUMEROS");
            }
        }
        private void txtusuario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("SOLO LETRAS");
            }
        }
        private void txtcontrol_Enter(object sender, EventArgs e)
        {
            if (txtcontrol.Text == "Ej. 1318094415")
            {
                txtcontrol.Text = "";
                txtcontrol.ForeColor = Color.Black;
                    
            }
                
        }
        private void txtcontrol_Leave(object sender, EventArgs e)
        {
            if (txtcontrol.Text == "")
            {
                txtcontrol.Text = "Ej. 1318094415";
                txtcontrol.ForeColor = Color.Silver;


            }
        }
        private void txtusuario_Enter(object sender, EventArgs e)
        {
            if (txtusuario.Text == "Ej. Medico")
            {
                txtusuario.Text = "";
                txtusuario.ForeColor = Color.Black;

            }
        }
        private void txtusuario_Leave(object sender, EventArgs e)
        {
            if (txtusuario.Text == "")
            {
                txtusuario.Text = "Ej. Medico";
                txtusuario.ForeColor = Color.Silver;


            }

        }
        private void txtdia_Enter(object sender, EventArgs e)
        {
            if (txtdia.Text == "AAAA/MM/DD")
            {
                txtdia.Text = "";
                txtdia.ForeColor = Color.Black;

            }
        }
        private void txtdia_Leave(object sender, EventArgs e)
        {
            if (txtdia.Text == "")
            {
                txtdia.Text = "AAAA/MM/DD";
                txtdia.ForeColor = Color.Silver;


            }

        }
        private void button1_Click(object sender, EventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {
            txtcontrol.Clear();
            txtusuario.Clear();
            txtdia.Clear();
            txtentrada.Clear();
            txtobservaciones.Clear();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtentrada_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("SOLO NUMEROS");
            }

        }

        private void txtobservaciones_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("SOLO LETRAS");
            }

        }

        private void txtdia_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("SOLO NUMEROS");
            }

        }
    }
}
